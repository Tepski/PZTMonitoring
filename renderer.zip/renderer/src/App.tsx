import Header from "./components/Header";
import TitleBar from "./components/TitleBar";
import Output from "./components/Output";
import TotalOutput from "./components/TotalOutput";
import PerModel from "./components/PerModel";

function App() {
  return (
    <div className="flex h-[100vh] w-[100vw] flex-col items-center select-none">
      <TitleBar />
      <div className="container flex flex-col h-full w-[97%] pb-4">
        <Header />
        <Output />
        <TotalOutput />
        <PerModel />
      </div>
    </div>
  );
}

export default App;
