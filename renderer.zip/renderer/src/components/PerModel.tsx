import { useState, useEffect } from "react";

const PerModel = () => {
  const [table, setTable] = useState<string[][]>([]);

  useEffect(() => {
    const tableContents = [["Per Model", "Dayshift", "NightShift"]];

    const models = ["HP", "5.3", "23W", "23A", "23P", "26MB", "15M"];

    for (const model of models) {
      const modelRow = [model, "", ""];
      tableContents.push(modelRow);
    }

    setTable(tableContents);
  }, []);

  return (
    <div className="flex h-full flex-1/2">
      <table className="w-full table-fixed">
        <tbody>
          {table?.map((row, rowIndex) => {
            return (
              <tr
                key={rowIndex.toString()}
                className={`${
                  rowIndex == 0
                    ? "bg-blue-400/40 font-semibold"
                    : rowIndex % 2 == 0 && "bg-gray-200"
                }`}
              >
                {row.map((col, colIndex) => {
                  return (
                    <td
                      key={colIndex.toString()}
                      className={`border-1 ${
                        colIndex == 0 ? "w-[10%] ps-4" : "text-center"
                      }`}
                    >
                      {col}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default PerModel;
