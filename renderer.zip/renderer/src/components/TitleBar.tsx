
const TitleBar = () => {
  return (
    <div className='flex items-center mb-2 w-full px-6 py-2  bg-blue-400/40'>
        <p className='text-2xl font-semibold'>
            PZT Output Monitoring
        </p>
        </div>
  )
}

export default TitleBar