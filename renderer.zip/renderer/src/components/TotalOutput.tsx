const TotalOutput = () => {
  const tableCotents = [
    ["DAYSHIFT", "NIGHTSHIFT"],
    [null, null],
  ];

  return (
    <div className=" my-2 flex justify-centes w-full flex-col h-full flex-1/4">
      <p className="text-4xl text-[#443838] py-4 font-semibold bg-blue-400/40 w-full text-center border-1">
        Total Output
      </p>
      <table className="w-full table-fixed h-full">
        <tbody>
          {tableCotents.map((row, rowIndex) => {
            return (
              <tr
                key={rowIndex.toString()}
                className={`text-center ${
                  rowIndex == 0
                    ? "font-semibold bg-gray-300 h-8"
                    : "h-auto font-bold text-2xl"
                }`}
              >
                {row.map((cell, colIndex) => {
                  return (
                    <td key={colIndex.toString()} className={`border-1`}>
                      {cell}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default TotalOutput;
