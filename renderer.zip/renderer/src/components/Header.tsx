const Header = () => {
  return (
    <div className="flex justify-between pb-2 items-center">
      <div className="">
        <input
          type="text"
          className="border-2 px-2 py-1 rounded-md"
          placeholder="Barcode/QTY"
        />
        <button className="bg-blue-500 mx-2 px-2 py-1 border-2 border-blue-500 active:bg-blue-600 rounded-md hover:cursor-pointer text-white shadow-md">
          SUBMIT
        </button>
      </div>

      <div className="flex gap-2">
        <input
          type="date"
          className="border-2 px-2 py-1 rounded-md"
          defaultValue={"08/04/2025"}
        />

        <button className="bg-blue-500 mx-2 px-2 py-1 border-2 border-blue-500 shadow-md active:bg-blue-600 rounded-md hover:cursor-pointer text-white">
          Download Report
        </button>
      </div>
    </div>
  );
};

export default Header;
